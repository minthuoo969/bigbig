<?php

/*
 * All database connection variables
 */

define('DB_USER',"netflix"); // db user
define('DB_PASSWORD',"flix"); // db password (mention your db password here)
define('DB_DATABASE',"netflixnew"); // database name
define('DB_SERVER',"localhost"); // db server

define('PURCHAGECODE',"XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX"); // your purchage code (if you dont have this contact me on primeflix6533@gmail.com)
define('PAYTM_MERCHANT_KEY', '9wPwxkQ2PPWtPDNk_');

define('DEMO',"yes"); // this is demo yes/no

//Ads Setting
// for enable type "true"
// for disable type "false"
DEFINE('PUBLISHER_ID',"ca-app-pub-3940256099942544~3347511713");

DEFINE('INTERSTITAL_AD',"true");
// for admob ads type "admob" or for fb type "fb"
DEFINE('INTERSTITAL_AD_TYPE',"fb");
DEFINE('INTERSTITAL_AD_ID',"IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID");

DEFINE('BANNER_AD',"true");
// for admob ads type "admob" or for fb type "fb"
DEFINE('BANNER_AD_TYPE',"admob");
DEFINE('BANNER_AD_ID',"ca-app-pub-3940256099942544/6300978111");

//after how many clicks show full screen interstitial ads
DEFINE('INTERSTITAL_AD_CLICK',"1");

//Promocode days -Refer and earn
DEFINE('NEW_USER_DAYS',"10");
DEFINE('OLD_USER_DAYS',"5");
DEFINE('REFER_DESC',"Invite your friends and Earn Premium Days. Your friend Get 10 days subscription bonus and you 5 days subscription bonus when they subscribe any plan.");

?>