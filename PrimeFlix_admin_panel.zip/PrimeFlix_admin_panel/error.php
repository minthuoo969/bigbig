<!DOCTYPE html>
<html lang="en">
<head>
<!-- Required meta tags -->
<meta charset="utf-8">
</head>
<body>
    
<p style="text-align: center;">Hi, Buyers</p>
<p style="text-align: center;">&nbsp;</p>
<p style="text-align: center;"><strong>This error page is showing to you because one of below reason:</strong></p>
<p style="text-align: center;">1. you have not entered your purchage code in&nbsp;db_config.php</p>
<p style="text-align: center;">2.you have not registed your website domain and purchage code with us.</p>
<p style="text-align: center;">&nbsp;</p>
<p style="text-align: center;">contact us on <strong>rajan6534@gmail.com</strong></p>

</body>
</html>